

import React, { useState,useEffect } from 'react';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import VerificationTable from './VerificationTable';
import UsersTable from './UsersTable';
import BookingsTable from './BookingsTable';
import QueriesTable from './QueriesTable';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const Admin = () => {
  const navigate= useNavigate()
  const [activeTab, setActiveTab] = useState('verification');
  useEffect(() => {
   if(sessionStorage.getItem("role")!= "admin"){
    toast.error("You are not authorized to access this page.");
    
navigate('/login')
   }
  }, [])
  
  return (
    <div className='container'>
      <Tabs
        defaultActiveKey="verification"
        id="uncontrolled-tab-example"
        className="mb-5 d-flex justify-content-center align-items-center"
        onSelect={(key) => setActiveTab(key)}
      >
        <Tab eventKey="verification" title="Verification SP">
          {activeTab === 'verification' && <VerificationTable />}
        </Tab>
        {/* <Tab eventKey="users" title="Users">
          {activeTab === 'users' && <UsersTable />}
        </Tab> */}
        <Tab eventKey="bookings" title="Booking">
          {activeTab === 'bookings' && <BookingsTable />}
        </Tab>
        {/* <Tab eventKey="queries" title="Con/Queries">
          {activeTab === 'queries' && <QueriesTable />}
        </Tab> */}
      </Tabs>
    </div>
  );
};

export default Admin;
