import React, { useEffect, useState } from 'react';
import firstimg from "../../Assets/HomePage/High coziness.png";
import { Modal, Button } from 'react-bootstrap'; 
import { getServices } from '../../Services/Api';
import Shop from "../../Assets/Rectangle13.png"
import { Link } from 'react-router-dom';
import Select from "react-select";
import "./Services.css"
import Carousel from 'react-bootstrap/Carousel';
import Mens from "../../Assets/saloon.png";
import Navbar from '../navbar/Navbar';

const Services = () => {
  
  const categories = {
    'Mens Saloon': 'menssaloon',
    'Womens Spa ': 'womensspa',
    'Painting': 'painting',
    // 'Plumb': 'plumbing',
    'Electrician': 'electrical',
    'AC Service': 'acservice',
    //'Home ': 'homeservices'
  };

  const carouselData = [
    "https://naturals.in/wp-content/uploads/2024/06/Untitled-design.png",
    "https://naturals.in/wp-content/uploads/2022/04/sc-4.jpg.webp",
    "https://naturals.in/wp-content/uploads/2022/04/sc-2.jpg.webp"
  ];

  const [showModal, setShowModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [data, setData] = useState([]);

  const handleModalOpen = (category) => {
    const categoryValue = categories[category];
    setSelectedCategory(categoryValue);
    setShowModal(true);
  };

  const handleModalClose = () => {
    setShowModal(false);
    setSelectedCategory('');
  };

  useEffect(() => {
    if (selectedCategory) {
      const payload = `category=${selectedCategory}`;
      getServices(payload)
        .then((res) => {
          console.log(res.data.lists);
          setData(res.data.lists);
        })
        .catch((err) => {
          console.log(err);
        });
    }
    console.log(data);
  }, [selectedCategory]);

  const [inputValue, setInputValue] = useState('');
  const [options, setOptions] = useState([
    {label:"Mens Saloon",value:"menssaloon"},
    { label: 'Womens Spa', value: 'womensspa' },
    { label: 'AC Service', value: 'acservice' },
    { label: 'Painting', value: 'painting' },
    
  ]);

  const handleInputChange = (newValue) => {
    setInputValue(newValue);
  };

  const handleChange = (selectedOption) => {
    setInputValue(selectedOption ? selectedOption.label : '');
    handleModalOpen(selectedOption.label);
  };

  const customComponents = {
    DropdownIndicator: null,
  };

  return (
    <>
    <Navbar/>
    <div className="container-fluid">
      <div className="d-flex flex-column flex-md-column justify-content-around align-items-center">
        <div className="col-9 mt-5">
          <span className="welcomeTag gradient-text">Welcome to He!</span>
          <Select
            components={customComponents}
            inputValue={inputValue}
            onInputChange={handleInputChange}
            onChange={handleChange}
            options={options}
            isClearable
            isSearchable
            placeholder="Search for Services"
            noOptionsMessage={() => 'Type to add new value'}
            className="selectBar"
          />
          <div className='d-flex justify-content-between mt-2'>
            {Object.keys(categories).map((filterKey) => (
              <div className='d-flex flex-row align-items-center ServiceBorder' key={filterKey} onClick={() => handleModalOpen(filterKey)} >
                <img src ={Mens} alt ="" style={{maxWidth:"56px"}}/>
                <h8 style={{ cursor: 'pointer' }}>
                  {filterKey}
                  </h8>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Carousel data-bs-theme="dark" className='container col-9 mt-4'>
        {carouselData.map((imageUrl, index) => (
          <Carousel.Item key={index}>
            <img
              className="d-block w-100 custom-carousel-image"
              src={imageUrl}
              alt={`Slide ${index + 1}`}
            />
            <Carousel.Caption>
              <h5 className='text-light'>Offers {index + 1}</h5>
              <p className='text-light'>Summer Combo Offer lets Book  .</p>
            </Carousel.Caption>
          </Carousel.Item>
        ))}
      </Carousel>

      <Modal show={showModal} onHide={handleModalClose}>
        <Modal.Header closeButton>
          <Modal.Title>{selectedCategory}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Selected Category: {selectedCategory}
          <div className="col-md-12 mt-3">
            <div className="row justify-content-center">
              {data.map((item, idx) => (
                <div key={idx} className="d-flex flex-column">
                  <Link to={`/singleServices/${item._id}`} >
                    <div className='d-flex flex-row justify-content-around mx-5 my-2' >
                      <div><img src={Shop} alt={`Image ${idx}`} className="img-fluid" style={{ width: "120px", height: "120px", borderRadius: "5px" }} /></div>
                      <div className='d-flex justify-content-between align-items-center'>
                        <div className='d-flex flex-column'>
                          <span >{item.serviceName}</span>
                          <span>{item.serviceType}</span>
                          <span>{item.price}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </div>
    </>
  );
};

export default Services;
